# Allo Inventory Reservation System

## Tech Stack
- Next.js
- TypeScript
- Prisma
- PostgreSQL
- TailwindCSS

## Setup

```bash
npm install
```

Create `.env`:

```env
DATABASE_URL="your_postgres_url"
```

Run migrations:

```bash
npx prisma migrate dev
```

Run seed:

```bash
npx prisma db seed
```

Run app:

```bash
npm run dev
```

## Expiry Mechanism
Reservations expire after 10 minutes. Expired reservations are released automatically.

## APIs
- GET /api/products
- GET /api/warehouses
- POST /api/reservations
- POST /api/reservations/:id/confirm
- POST /api/reservations/:id/release
