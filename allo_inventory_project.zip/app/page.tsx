export default function Home() {
  return (
    <div style={{ padding: 20 }}>
      <h1>Allo Inventory Reservation System</h1>
      <p>Product listing page</p>
    </div>
  )
}
